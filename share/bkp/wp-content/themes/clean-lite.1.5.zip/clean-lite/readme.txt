/*-----------------------------------------------------------------------------------*/
/* Clean Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Clean Lite
Theme URI       :   https://www.sktthemes.net/shop/free-clean-wordpress-theme/
Version         :   1.5
Tested up to    :   WP 4.6.1
Author          :   SKT Themes
Author URI      :   https://www.sktthemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.

2 -     jQuery Nivo Slider
	Copyright 2012, Dev7studios, under MIT license
	http://nivo.dev7studios.com


3 - Roboto Condensed - https://www.google.com/fonts/specimen/Roboto+Condensed
	License: Distributed under the terms of the Apache License, version 2.0 			http://www.apache.org/licenses/



4 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license					(https://creativecommons.org/about/cc0)

	Slider Images

	https://pixabay.com/en/apple-water-nature-waves-783660/
	https://pixabay.com/en/dandelion-sky-flower-nature-seeds-463928/	
	https://pixabay.com/en/dandelion-flower-nature-blue-501190/


For any help you can mail us at support[at]sktthemes.com